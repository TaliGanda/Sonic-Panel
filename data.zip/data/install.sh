curl -s -L https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/proxylist.txt -o proxy.txt
curl -s -L https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/proxylist.txt -o proxies.txt

import os
import sys
import httpx
from colorama import Fore, init
init(autoreset=True)

fr = Fore.RED
fg = Fore.GREEN
fy = Fore.YELLOW
fw = Fore.WHITE
fre = Fore.RESET

list = [
'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt',
'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt',
'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt',
'https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt',
'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
'https://raw.githubusercontent.com/proxylist-to/proxy-list/main/http.txt',
'https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/raw.txt',
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt',
'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt',
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt',
'https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt',
'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt',
'https://api.openproxylist.xyz/http.txt',
'https://api.proxyscrape.com/v2/?request=displayproxies',
'https://api.proxyscrape.com/?request=displayproxies&proxytype=http',
'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
'https://www.proxydocker.com/en/proxylist/download?email=noshare&country=all&city=all&port=all&type=all&anonymity=all&state=all&need=all',
'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=anonymous',
'http://worm.rip/http.txt',
'https://proxyspace.pro/http.txt',
'https://multiproxy.org/txt_all/proxy.txt',
'https://proxy-spider.com/api/proxies.example.txt',
'https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/HTTP.txt',
'https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/http.txt',
'https://raw.githubusercontent.com/HyperBeats/proxy-list/main/http.txt',
'https://raw.githubusercontent.com/HyperBeats/proxy-list/main/https.txt',
'https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt',
'https://api.proxyscrape.com/?request=displayproxies&proxytype=http',
'https://api.openproxylist.xyz/http.txt',
'http://alexa.lr2b.com/proxylist.txt',
'https://multiproxy.org/txt_all/proxy.txt',
'https://proxyspace.pro/http.txt',
"https://proxyspace.pro/https.txt",
"https://proxy-spider.com/api/proxies.example.txt",
"http://proxysearcher.sourceforge.net/Proxy%20List.php?type=http",
"https://raw.githubusercontent.com/RX4096/proxy-list/main/online/all.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/http.txt",
"https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
"https://raw.githubusercontent.com/shiftytr/proxy-list/master/proxy.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
"https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt",
"https://raw.githubusercontent.com/UserR3X/proxy-list/main/online/http.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
"https://raw.githubusercontent.com/UserR3X/proxy-list/main/online/https.txt",
"https://raw.githubusercontent.com/BlackSnowDot/proxylist-update-every-minute/main/https.txt",
"https://raw.githubusercontent.com/BlackSnowDot/proxylist-update-every-minute/main/http.txt",
"https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt",
"https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt",
"http://rootjazz.com/proxies/proxies.txt",
"http://spys.me/proxy.txt",
"https://sheesh.rip/http.txt",
"http://worm.rip/http.txt",
"http://www.proxyserverlist24.top/feeds/posts/default",
"https://www.proxy-list.download/api/v1/get?type=http",
"https://www.proxyscan.io/download?type=http",
"https://www.my-proxy.com/free-anonymous-proxy.html",
"https://www.my-proxy.com/free-transparent-proxy.html",
"https://www.my-proxy.com/free-proxy-list.html",
"https://www.my-proxy.com/free-proxy-list-2.html",
"https://www.my-proxy.com/free-proxy-list-3.html",
"https://www.my-proxy.com/free-proxy-list-4.html",
"https://www.my-proxy.com/free-proxy-list-5.html",
"https://www.my-proxy.com/free-proxy-list-6.html",
"https://www.my-proxy.com/free-proxy-list-7.html",
"https://www.my-proxy.com/free-proxy-list-8.html",
"https://www.my-proxy.com/free-proxy-list-9.html",
"https://www.my-proxy.com/free-proxy-list-10.html",
"https://www.freeproxychecker.com/result/http_proxies.txt",
"https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4",
"https://api.proxyscrape.com/?request=displayproxies&proxytype=socks4",
"https://api.proxyscrape.com/?request=displayproxies&proxytype=socks4&country=all",
"https://api.openproxylist.xyz/socks4.txt",
"https://proxyspace.pro/socks4.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/socks4.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
"http://worm.rip/socks4.txt",
"https://www.proxy-list.download/api/v1/get?type=socks4",
"https://www.proxyscan.io/download?type=socks4",
"https://www.my-proxy.com/free-socks-4-proxy.html",
"http://www.socks24.org/feeds/posts/default",
"https://www.freeproxychecker.com/result/socks4_proxies.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/socks4.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/socks4.txt",
"https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/SOCKS4.txt",
"https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/SOCKS5.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/socks5.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/socks5.txt",
"https://api.openproxylist.xyz/socks5.txt",
"https://api.proxyscrape.com/?request=displayproxies&proxytype=socks5",
"https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5",
"https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5",
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000&country=all&simplified=true",
"https://proxyspace.pro/socks5.txt",
"https://raw.githubusercontent.com/manuGMG/proxy-365/main/SOCKS5.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/socks5.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
"https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt",
"https://raw.githubusercontent.com/BlackSnowDot/proxylist-update-every-minute/main/socks.txt",
"http://worm.rip/socks5.txt",
"http://www.socks24.org/feeds/posts/default",
"https://www.freeproxychecker.com/result/socks5_proxies.txt",
"https://www.proxy-list.download/api/v1/get?type=socks5",
"https://www.proxyscan.io/download?type=socks5",
"https://www.my-proxy.com/free-socks-5-proxy.html",
]  
         

if __name__ == "__main__":
    file = "proxy.txt"
    
    try:
        if os.path.isfile(file):
            os.system('cls' if os.name == 'nt' else 'clear')
            os.remove(file)
            print("{}File {} Sudah Ada!\n{}Memulai Mengunduh {} Yang Baru!\n".format(fr, file, fy, file))
            with open(file, 'a') as data:
                for proxy in list:
                    data.write(httpx.get(proxy).text)
                    print(" -| mengambil {}{}".format(fg, proxy))
        else:
            os.system('cls' if os.name == 'nt' else 'clear')
            with open(file, 'a') as data:
                for proxy in list:
                    data.write(httpx.get(proxy).text)
                    print(" -| mengambil {}{}".format(fg, proxy))
    
        with open(file, 'r') as count:
            total = sum(1 for line in count)
        print("\n{}( {}{} {}) {}Proxy Berhasil Di Unduh.". format(fw, fy, total, fw, fg))
    
    except IndexError:
        sys.exit(1)
        